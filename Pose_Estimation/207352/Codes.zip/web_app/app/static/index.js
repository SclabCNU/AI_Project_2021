$(document).ready(function() {

	$('form').on('submit', function(event) {
		console.log($('#youtube_link').val())
		$.ajax({
			data : {
				youtube : $('#youtube_link').val(),
			},
			type : 'POST',
			url : '/process'
		})
		.done(function(data) {
			console.log(data)
			if (data.error) {
				$('#errorAlert').text(data.error).show();
				$('#successAlert').hide();
			}
			else {
				$('#successAlert').text(data.status).show();
				$('#errorAlert').hide();
			}

		});

		event.preventDefault();

	});

});