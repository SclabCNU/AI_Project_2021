# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""
from datetime import datetime

from app         import db
from flask_login import UserMixin

class Users(db.Model, UserMixin):

    __tablename__ = 'Users'

    id       = db.Column(db.Integer,     primary_key=True)
    user     = db.Column(db.String(64),  unique = True)
    email    = db.Column(db.String(120), unique = True)
    password = db.Column(db.String(500))
    videos =db.relationship('Videos', backref='Videos')

    def __init__(self, user, email, password):
        self.user       = user
        self.password   = password
        self.email      = email

    def __repr__(self):
        return str(self.id) + ' - ' + str(self.user)

    def save(self):

        # inject self into db session    
        db.session.add(self)

        # commit change and save the object
        db.session.commit( )

        return self

class Videos(db.Model):
    __tablename__ = 'Videos'

    id = db.Column(db.Integer,     primary_key=True)
    video_input = db.Column(db.String(128))
    video_output = db.Column(db.String(128))
    input_time = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('Users.id'), nullable=False)
    status = db.Column(db.String(64))

    def save(self):

        # inject self into db session
        db.session.add(self)

        # commit change and save the object
        db.session.commit()
        return self

    def __init__(self, video_input, user_id, status):
        self.video_input = video_input
        self.user_id = user_id
        self.status = status