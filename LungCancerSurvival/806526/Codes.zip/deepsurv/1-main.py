import os
import torch
import torch.optim as optim
import prettytable as pt

from networks import DeepSurv
from networks import NegativeLogLikelihood
# from datasets import SurvivalDataset
from datasets import LCNSCLCDataset
from utils import read_config
from utils import c_index
from utils import adjust_learning_rate
from utils import create_logger

from preprocess import preprocess_clinical_data_to_deepsurv
from preprocess import preprocess_clinical_radiomic_data_to_deepsurv
from preprocess import preprocess_radiomic_data_to_deepsurv
import random
import numpy as np


def seed_worker(worker_id):
    worker_seed = torch.initial_seed() % 2**32
    np.random.seed(worker_seed)
    random.seed(worker_seed)


def seed_everything(seed):
    torch.manual_seed(seed)
    random.seed(0)
    np.random.seed(0)


def train(ini_file, device='cuda'):
    ''' Performs training according to .ini file

    :param ini_file: (String) the path of .ini file
    :return best_c_index: the best c-index
    '''

    SEED = 2020
    seed_everything(SEED)

    # reads configuration from .ini file
    config = read_config(ini_file)

    print(config)
    # builds network|criterion|optimizer based on configuration
    model = DeepSurv(config['network']).to(device)

    criterion = NegativeLogLikelihood(config['network'],
                                      device=device).to(device)

    optimizer = eval('optim.{}'.format(config['train']['optimizer']))(model.parameters(),
                                                                      lr=config['train']['learning_rate'])

    # constructs data loaders based on configuration
    if config['train']['data_feature'] == 'clinical':
        print('Load combinination of clinical and radiomic features')
        train_deepsurv_data, test_deepsurv_data = preprocess_clinical_data_to_deepsurv(config['train']['excel_file'],
                                                                                       event_col='Deadstatus.event',
                                                                                       time_col='Survival.time')

    elif config['train']['data_feature'] == 'combine':
        print('Load combinination of clinical and radiomic features')
        train_deepsurv_data, test_deepsurv_data = preprocess_clinical_radiomic_data_to_deepsurv(config['train']['excel_file'],
                                                                                                event_col='Deadstatus.event',
                                                                                                time_col='Survival.time', save_params=True)
    elif config['train']['data_feature'] == 'radiomic':
        print('Load radiomic features')
        train_deepsurv_data, test_deepsurv_data = preprocess_radiomic_data_to_deepsurv(config['train']['excel_file'],
                                                                                       event_col='Deadstatus.event',
                                                                                       time_col='Survival.time')
    else:
        raise

    train_dataset = LCNSCLCDataset(**train_deepsurv_data)
    test_dataset = LCNSCLCDataset(**test_deepsurv_data)

    g = torch.Generator()
    g.manual_seed(SEED)
    train_loader = torch.utils.data.DataLoader(train_dataset,
                                               batch_size=len(train_dataset),
                                               num_workers=10,
                                               worker_init_fn=seed_worker,
                                               generator=g)

    test_loader = torch.utils.data.DataLoader(test_dataset,
                                              batch_size=len(test_dataset),
                                              num_workers=10,
                                              worker_init_fn=seed_worker,
                                              generator=g)

    # Training
    best_c_index = 0
    flag = 0
    for epoch in range(1, config['train']['epochs'] + 1):
        # Adjusts learning rate
        lr = adjust_learning_rate(optimizer, epoch,
                                  config['train']['learning_rate'],
                                  config['train']['lr_decay_rate'])
        # Train step
        model.train()
        for X, t, e in train_loader:
            X = X.to(device)
            t = t.to(device)
            e = e.to(device)

            # Makes predictions
            risk_pred = model(X)
            train_loss = criterion(risk_pred, t, e, model)
            train_c = c_index(-risk_pred, t, e)
            # Updates parameters
            optimizer.zero_grad()
            train_loss.backward()
            optimizer.step()

        # Valid step
        model.eval()
        for X, t, e in test_loader:
            X = X.to(device)
            t = t.to(device)
            e = e.to(device)

            # makes predictions
            with torch.no_grad():
                risk_pred = model(X)
                valid_loss = criterion(risk_pred, t, e, model)
                valid_c = c_index(-risk_pred, t, e)
                if best_c_index < valid_c:
                    best_c_index = valid_c
                    flag = 0
                    # saves the best model
                    torch.save({
                        'model': model.state_dict(),
                        'optimizer': optimizer.state_dict(),
                        'epoch': epoch}, os.path.join(models_dir, ini_file.split('/')[-1] + '.pth'))
                else:
                    flag += 1
                    if flag >= patience:
                        return best_c_index

        # Notes that, train loader and valid loader both have one batch!!!
        print('\rEpoch: {}\tTLoss: T:{:.4f}\t(V:{:.4f})\tc-index: T:{:.4f}(V:{:.4f})\tlr: {:g}'.format(
            epoch, train_loss.item(), valid_loss.item(), train_c, valid_c, lr), end='', flush=False)

    return best_c_index


if __name__ == '__main__':
    # global settings
    logs_dir = 'logs'
    models_dir = os.path.join(logs_dir, 'models')
    if not os.path.exists(models_dir):
        os.makedirs(models_dir)
    logger = create_logger(logs_dir)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    configs_dir = 'configs'
    params = [('LCNSCL', 'lc_nscl_combine.ini')]
    patience = 50
    # training
    headers = []
    values = []
    for name, ini_file in params:
        logger.info('Running {}({})...'.format(name, ini_file))
        best_c_index = train(os.path.join(configs_dir, ini_file), device)
        headers.append(name)
        values.append('{:.6f}'.format(best_c_index))
        print('')
        logger.info("The best valid c-index: {}".format(best_c_index))
        logger.info('')

    # prints results
    tb = pt.PrettyTable()
    tb.field_names = headers
    tb.add_row(values)
    logger.info(tb)
