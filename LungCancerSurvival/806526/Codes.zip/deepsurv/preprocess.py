import pickle as pkl
from typing import Tuple
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, OrdinalEncoder
from sklearn.model_selection import train_test_split


def split_train_test(df, test_size=0.3, random_state=2020):
    df_train, df_test = train_test_split(df,
                                         test_size=test_size,
                                         random_state=random_state)
    return df_train, df_test


def dataframe_to_deepsurv_ds(df, event_col, time_col):
    """Convert Pandas DataFrame to DeepSurv Format

    Args:
        df (pd.DataFrame): Pandas DataFrame
        event_col (str): event column name
        time_col (str): survival time column name

    Returns:
        dict: A dictionary of input features, event label, and survival time
    """
    # Extract the event and time columns as numpy arrays
    e = df[event_col].values.astype(np.int32)
    t = df[time_col].values.astype(np.float32)

    # Extract the patient's covariates as a numpy array
    x_df = df.drop([event_col, time_col], axis=1)
    x = x_df.values.astype(np.float32)

    # Return the deep surv dictionary
    return {
        'X': x,
        'e': e,
        't': t
    }


def label_encode_input(df, column_name):
    encoder = LabelEncoder()
    df[column_name] = encoder.fit_transform(
        df[column_name].to_numpy().reshape((-1, 1)))
    return df


def ordinal_encode_input(df: pd.DataFrame, column_name: str):
    # Overall.stage

    # import mipkit;mipkit.debug.set_trace();exit();

    unique_val = df[column_name].unique()
    unique_val.sort()
    # print('overal_stage:', unique_val)

    encoder = OrdinalEncoder(categories=[unique_val])
    df['Overall.stage'] = encoder.fit_transform(
        df['Overall.stage'].to_numpy().reshape((-1, 1)))
    return df


def normalize_input(df):
    from sklearn.preprocessing import Normalizer


def standard_input(df, save_scaler=True, prefix='radiomic'):
    from sklearn.preprocessing import StandardScaler
    standard_scaler = StandardScaler()
    standard_scaler.fit(df)
    if save_scaler:
        with open(f'{prefix}_standard_scaler.pkl', 'wb') as f:
            pkl.dump(standard_scaler, f)
    return standard_scaler.transform(df)


def minmax_input(df, prefix, save_scaler=True):
    from sklearn.preprocessing import MinMaxScaler
    minmax_scaler = MinMaxScaler()
    minmax_scaler.fit(df)
    if save_scaler:
        with open(f'{prefix}_minmax_scaler.pkl', 'wb') as f:
            pkl.dump(minmax_scaler, f)
    return minmax_scaler.transform(df)


def read_excel(excel_path: str):
    return pd.read_excel(excel_path)


def preprocess_clinical_data(path: str):
    # PATH = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/LC_NSCLC_CLINICAL_n=2687_20210202.xlsx'

    df = read_excel(path)

    # Fill Nan by their mean
    df = df.fillna(df.mean())
    df = df.rename(columns={'Clinical.T.Stage': 'Clinical.T.stage'}
                   )

    # df_clinical = df_clinical[df_clinicaldf_clinical['Smoking.status'] != 9]
    df = df[df['Deadstatus.event'].apply(
        lambda x: int(x)) != 9]
    df = df[[
        'gender', 'age', 'Survival.time', 'Histology',
        'Overall.stage', 'Clinical.T.stage', 'Clinical.M.stage',
        'Clinical.N.stage', 'Smoking.status', 'Smoking.amount', 'Deadstatus.event']]
    # One-hot encoding: 0 - 1
    df = label_encode_input(df,
                            column_name='gender')

    df['age'] /= 100  # Normalize age

    # One-hot encoding
    df = pd.get_dummies(df, columns=[
        'Histology',  'Overall.stage', 'Clinical.T.stage', 'Clinical.M.stage', 'Clinical.N.stage'])

    df['Smoking.amount'] = minmax_input(
        df['Smoking.amount'].values.reshape((-1, 1)), prefix='smoking_amount').reshape(-1)

    df['Smoking.amount'] = minmax_input(
        df['Smoking.amount'].values.reshape((-1, 1)), prefix='smoking_amount').reshape(-1)

    df_clinical_train, df_clinical_test = split_train_test(df,
                                                           test_size=0.3,
                                                           random_state=2020)
    return df_clinical_train, df_clinical_test


def preprocess_radiomic_data(path: str):
    df_radiomic = read_excel(path)

    # Fill Nan by their mean
    df_radiomic = df_radiomic.fillna(df_radiomic.mean())

    df_radiomic = standard_input(df_radiomic)
    return df_radiomic


def preprocess_clinical_radiomic_data(combination_path, save_params):
    # PATH = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/LC_NSCLC_CLINICAL_n=2687_20210202.xlsx'
    # COMBINE_PATH = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/radiomic_clinical_20210202.xlsx'
    df = read_excel(combination_path)

    # Fill Nan by their mean
    df = df.fillna(df.mean())
    df = df.rename(columns={'Clinical.T.Stage': 'Clinical.T.stage'}
                   )

    df = df[df['Deadstatus.event'].apply(lambda x: int(x)) != 9]

    df = df.drop(columns=['PatientID',
                          'Mcode',
                          'Mcode.description',
                          ])

    # Radiomic Features
    df.iloc[:, 11:] = standard_input(
        df.iloc[:, 11:], prefix='radiomic', save_scaler=save_params)

    # One-hot encoding: 0 - 1
    df = label_encode_input(df,
                            column_name='gender')

    df['age'] /= 100  # Normalize age

    # One-hot encoding
    df = pd.get_dummies(df, columns=[
        'Histology',  'Overall.stage', 'Clinical.T.stage', 'Clinical.M.stage', 'Clinical.N.stage'])

    df['Smoking.amount'] = minmax_input(
        df['Smoking.amount'].values.reshape((-1, 1)), prefix='smoking_amount', save_scaler=save_params).reshape(-1)

    df_train, df_test = split_train_test(df,
                                         test_size=0.3,
                                         random_state=2020)
    return df_train, df_test


def preprocess_radiomic_data(combination_path):
    # PATH = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/LC_NSCLC_CLINICAL_n=2687_20210202.xlsx'
    # COMBINE_PATH = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/radiomic_clinical_20210202.xlsx'
    df = read_excel(combination_path)

    # Fill Nan by their mean
    df = df.fillna(df.mean())
    df = df.rename(columns={'Clinical.T.Stage': 'Clinical.T.stage'}
                   )

    df = df[df['Deadstatus.event'].apply(lambda x: int(x)) != 9]

    # Drop all clinical information
    df = df.drop(columns=['PatientID',
                          'Mcode',
                          'Mcode.description',
                          'gender', 'age', 'Histology',
                          'Overall.stage', 'Clinical.T.stage', 'Clinical.M.stage',
                          'Clinical.N.stage', 'Smoking.status', 'Smoking.amount'
                          ])

    # df.iloc[:, 2:] = standard_input(df.iloc[:, 2:])
    df_train, df_test = split_train_test(df,
                                         test_size=0.3,
                                         random_state=2020)
    return df_train, df_test


def preprocess_clinical_data_to_deepsurv(path: str,
                                         event_col: str = 'Deadstatus.event',
                                         time_col: str = 'Survival.time'):
    df_clinical_train, df_clinical_test = preprocess_clinical_data(path)
    deepsurv_clinical_train = dataframe_to_deepsurv_ds(df_clinical_train,
                                                       event_col=event_col,
                                                       time_col=time_col)
    deepsurv_clinical_test = dataframe_to_deepsurv_ds(df_clinical_test,
                                                      event_col=event_col,
                                                      time_col=time_col)
    return (deepsurv_clinical_train, deepsurv_clinical_test)


def preprocess_clinical_radiomic_data_to_deepsurv(path: str,
                                                  event_col: str = 'Deadstatus.event',
                                                  time_col: str = 'Survival.time', save_params=False):
    df_train, df_test = preprocess_clinical_radiomic_data(
        path, save_params=save_params)

    print('All columns: ', df_train.columns)
    deepsurv_train = dataframe_to_deepsurv_ds(df_train,
                                              event_col=event_col,
                                              time_col=time_col)
    deepsurv_test = dataframe_to_deepsurv_ds(df_test,
                                             event_col=event_col,
                                             time_col=time_col)
    return (deepsurv_train, deepsurv_test)


def preprocess_radiomic_data_to_deepsurv(path: str,
                                         event_col: str = 'Deadstatus.event',
                                         time_col: str = 'Survival.time'):
    df_train, df_test = preprocess_radiomic_data(
        path)

    deepsurv_train = dataframe_to_deepsurv_ds(df_train,
                                              event_col=event_col,
                                              time_col=time_col)
    deepsurv_test = dataframe_to_deepsurv_ds(df_test,
                                             event_col=event_col,
                                             time_col=time_col)
    return (deepsurv_train, deepsurv_test)
