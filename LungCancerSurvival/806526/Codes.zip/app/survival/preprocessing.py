import matplotlib.pyplot as plt
import pickle as pkl
from typing import Tuple
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, OrdinalEncoder
from sklearn.model_selection import train_test_split


def split_train_test(df, test_size=0.3, random_state=2020):
    df_train, df_test = train_test_split(df,
                                         test_size=test_size,
                                         random_state=random_state)
    return df_train, df_test


def dataframe_to_deepsurv_ds(df, event_col, time_col):
    """Convert Pandas DataFrame to DeepSurv Format

    Args:
        df (pd.DataFrame): Pandas DataFrame
        event_col (str): event column name
        time_col (str): survival time column name

    Returns:
        dict: A dictionary of input features, event label, and survival time
    """
    # Extract the event and time columns as numpy arrays
    e = df[event_col].values.astype(np.int32)
    t = df[time_col].values.astype(np.float32)

    # Extract the patient's covariates as a numpy array
    x_df = df.drop([event_col, time_col], axis=1)
    x = x_df.values.astype(np.float32)

    # Return the deep surv dictionary
    return {
        'X': x,
        'e': e,
        't': t
    }


def label_encode_input(df, column_name):
    encoder = LabelEncoder()
    df[column_name] = encoder.fit_transform(
        df[column_name].to_numpy().reshape((-1, 1)))
    return df


def ordinal_encode_input(df: pd.DataFrame, column_name: str):
    # Overall.stage
    unique_val = df[column_name].unique()
    unique_val.sort()
    # print('overal_stage:', unique_val)

    encoder = OrdinalEncoder(categories=[unique_val])
    df['Overall.stage'] = encoder.fit_transform(
        df['Overall.stage'].to_numpy().reshape((-1, 1)))
    return df


def normalize_input(df):
    from sklearn.preprocessing import Normalizer


def standard_input(df, save_scaler=True):
    from sklearn.preprocessing import StandardScaler
    standard_scaler = StandardScaler()
    if save_scaler:
        with open('scaler.pkl', 'wb') as f:
            pkl.dump(standard_scaler, f)
    return standard_scaler.fit_transform(df)


def minmax_input(df):
    from sklearn.preprocessing import MinMaxScaler
    minmax_scaler = MinMaxScaler()
    return minmax_scaler.fit_transform(df)


def read_excel(excel_path: str):
    return pd.read_excel(excel_path)


def preprocess_clinical_data(path: str):
    # PATH = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/LC_NSCLC_CLINICAL_n=2687_20210202.xlsx'

    df_clinical = read_excel(path)

    # Fill Nan by their mean
    df_clinical = df_clinical.fillna(df_clinical.mean())
    df_clinical = df_clinical.rename(columns={'Clinical.T.Stage': 'Clinical.T.stage'}
                                     )

    df_clinical = df_clinical[df_clinical['Smoking.status'] != 9]
    df_clinical = df_clinical[[
        'gender', 'age', 'Survival.time', 'Histology',
        'Overall.stage', 'Clinical.T.stage', 'Clinical.M.stage',
        'Clinical.N.stage', 'Smoking.status', 'Smoking.amount', 'Deadstatus.event']]

    df_clinical = ordinal_encode_input(df_clinical,
                                       column_name='Overall.stage')
    df_clinical = label_encode_input(df_clinical,
                                     column_name='Histology')
    df_clinical = label_encode_input(df_clinical,
                                     column_name='gender')

    df_clinical_train, df_clinical_test = split_train_test(df_clinical,
                                                           test_size=0.3,
                                                           random_state=2020)
    return df_clinical_train, df_clinical_test


def preprocess_radiomic_data(path: str):
    df_radiomic = read_excel(path)

    # Fill Nan by their mean
    df_radiomic = df_radiomic.fillna(df_radiomic.mean())

    df_radiomic = standard_input(df_radiomic)
    return df_radiomic


def preprocess_clinical_radiomic_data(combination_path):
    # PATH = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/LC_NSCLC_CLINICAL_n=2687_20210202.xlsx'
    # COMBINE_PATH = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/radiomic_clinical_20210202.xlsx'
    df = read_excel(combination_path)

    # Fill Nan by their mean
    df = df.fillna(df.mean())
    df = df.rename(columns={'Clinical.T.Stage': 'Clinical.T.stage'}
                   )

    df = df[df['Smoking.status'] != 9]

    df = df.drop(columns=['PatientID',
                          'Mcode',
                          'Mcode.description',
                          ])

    # df = df[[
    #     'gender', 'age', 'Survival.time', 'Histology',
    #     'Overall.stage', 'Clinical.T.stage', 'Clinical.M.stage',
    #     'Clinical.N.stage', 'Smoking.status', 'Smoking.amount', 'Deadstatus.event']]

    # df = ordinal_encode_input(df,
    #                           column_name='Overall.stage')
    # df = label_encode_input(df,
    #                         column_name='Histology')
    # df = label_encode_input(df,
    #                         column_name='gender')

    df['age'] /= 100  # Normalize age

    # One-hot encoding
    df = pd.get_dummies(df, columns=[
        'Histology',  'Overall.stage', 'Clinical.T.stage', 'Clinical.M.stage', 'Clinical.N.stage'])

    df['Smoking.amount'] = minmax_input(
        df['Smoking.amount'].values.reshape((-1, 1)), prefix='smoking_amount', save_scaler=save_params).reshape(-1)

    df.iloc[:, 11:] = standard_input(df.iloc[:, 11:])
    df_train, df_test = split_train_test(df,
                                         test_size=0.3,
                                         random_state=2020)
    return df_train, df_test


def preprocess_radiomic_data(combination_path):
    # PATH = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/LC_NSCLC_CLINICAL_n=2687_20210202.xlsx'
    # COMBINE_PATH = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/radiomic_clinical_20210202.xlsx'
    df = read_excel(combination_path)

    # Fill Nan by their mean
    df = df.fillna(df.mean())
    df = df.rename(columns={'Clinical.T.Stage': 'Clinical.T.stage'}
                   )

    df = df[df['Smoking.status'] != 9]

    # Drop all clinical information
    df = df.drop(columns=['PatientID',
                          'Mcode',
                          'Mcode.description',
                          'gender', 'age', 'Histology',
                          'Overall.stage', 'Clinical.T.stage', 'Clinical.M.stage',
                          'Clinical.N.stage', 'Smoking.status', 'Smoking.amount'
                          ])

    df.iloc[:, 2:] = standard_input(df.iloc[:, 2:])
    df_train, df_test = split_train_test(df,
                                         test_size=0.3,
                                         random_state=2020)
    return df_train, df_test


def preprocess_clinical_data_to_deepsurv(path: str,
                                         event_col: str = 'Deadstatus.event',
                                         time_col: str = 'Survival.time'):
    df_clinical_train, df_clinical_test = preprocess_clinical_data(path)
    deepsurv_clinical_train = dataframe_to_deepsurv_ds(df_clinical_train,
                                                       event_col=event_col,
                                                       time_col=time_col)
    deepsurv_clinical_test = dataframe_to_deepsurv_ds(df_clinical_test,
                                                      event_col=event_col,
                                                      time_col=time_col)
    return (deepsurv_clinical_train, deepsurv_clinical_test)


def preprocess_clinical_radiomic_data_to_deepsurv(path: str,
                                                  event_col: str = 'Deadstatus.event',
                                                  time_col: str = 'Survival.time'):
    df_train, df_test = preprocess_clinical_radiomic_data(
        path)
    deepsurv_train = dataframe_to_deepsurv_ds(df_train,
                                              event_col=event_col,
                                              time_col=time_col)
    deepsurv_test = dataframe_to_deepsurv_ds(df_test,
                                             event_col=event_col,
                                             time_col=time_col)
    return (deepsurv_train, deepsurv_test)


def preprocess_radiomic_data_to_deepsurv(path: str,
                                         event_col: str = 'Deadstatus.event',
                                         time_col: str = 'Survival.time'):
    df_train, df_test = preprocess_radiomic_data(
        path)
    deepsurv_train = dataframe_to_deepsurv_ds(df_train,
                                              event_col=event_col,
                                              time_col=time_col)
    deepsurv_test = dataframe_to_deepsurv_ds(df_test,
                                             event_col=event_col,
                                             time_col=time_col)
    return (deepsurv_train, deepsurv_test)


def find_nearest(array, value):
    array = np.asarray(array)
    idx = (np.abs(array - value)).argmin()
    return array[idx], idx


def draw_survival_curve(surv_fn):
    plt.figure(figsize=(4.7, 4.7))
    plt.step(surv_fn.x, surv_fn.y, where="post")
    plt.ylim(0, 1)
    # plt.ylabel("Probability of survival $P(T > t)$")
    # plt.xlabel("Time $t$ (day)")
    plt.grid()

    # Draw estimated survival day at P(t)=0.5
    threshold = 0.5
    val, i = find_nearest(surv_fn.y, threshold)
    pred_surv_day = int(surv_fn.x[i])

    # x, y = 99, 0.5
    plt.plot(pred_surv_day, threshold, marker='o', color='red')
    arrowprops = {'arrowstyle': '-', 'ls': '--', 'color': 'red'}

    plt.annotate('', xy=(pred_surv_day, threshold), xytext=(pred_surv_day, 0),
                 textcoords=plt.gca().get_xaxis_transform(),
                 arrowprops=arrowprops,
                 va='top', ha='center')

    plt.annotate('', xy=(pred_surv_day, threshold), xytext=(0, threshold),
                 textcoords=plt.gca().get_yaxis_transform(),
                 arrowprops=arrowprops,
                 va='center', ha='right')

    style = dict(size=12, color='red')
    plt.text(pred_surv_day+100, threshold,
             f"({threshold}, {pred_surv_day})", ha='left', **style)
    plt.tight_layout()
    plt.savefig('tmp/survival_curve.png', dpi=500)
