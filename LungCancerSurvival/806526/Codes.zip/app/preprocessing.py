import numpy as np
import cv2
import itk


def load_DICOM_series(folder_dir):
    # https://itk.org/ITKExamples/src/IO/GDCM/ReadDICOMSeriesAndWrite3DImage/Documentation.html
    PixelType = itk.ctype("signed short")
    Dimension = 3

    ImageType = itk.Image[PixelType, Dimension]

    namesGenerator = itk.GDCMSeriesFileNames.New()
    namesGenerator.SetUseSeriesDetails(True)
    namesGenerator.AddSeriesRestriction("0008|0021")
    namesGenerator.SetGlobalWarningDisplay(False)
    namesGenerator.SetDirectory(folder_dir)

    # Beware, seriesUID is a tuple
    # Example:
    # ('1.2.840.113619.2.379.114374080023902.100461.1600744141171.5.33.75000051251220200825',)
    seriesUID = namesGenerator.GetSeriesUIDs()

    seriesIdentifier = seriesUID[0]  # Get the first one
    fileNames = namesGenerator.GetFileNames(seriesIdentifier)

    reader = itk.ImageSeriesReader[ImageType].New()
    dicomIO = itk.GDCMImageIO.New()
    reader.SetImageIO(dicomIO)
    reader.SetFileNames(fileNames)
    reader.ForceOrthogonalDirectionOff()
    itk_image = reader.GetOutput()
    output_arr = itk.GetArrayFromImage(itk_image)
    return output_arr


def normalize_CT_PET(ct_pet_image):
    ct_pet_image = cv2.normalize(
        ct_pet_image, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_16U)
    return ct_pet_image


def crop_lung_image(ct_mri_image, width_ratio=0.6, height_ratio=0.6):
    d, h, w = ct_mri_image.shape
    return ct_mri_image[..., int(h//2 - (height_ratio/2)*h):int(h//2 + (height_ratio/2)*h),
                        int(w//2 - (width_ratio/2)*w):int(w//2 + (width_ratio/2)*w)]


def extract_lung_slides(ct_mri_image, relative_upper=0.9, relative_lower=0.5):
    num_slides = ct_mri_image.shape[0]
    upper_slide_pos = int(num_slides * relative_upper)
    lower_slide_pos = int(num_slides * relative_lower)
    return ct_mri_image[lower_slide_pos:upper_slide_pos, ...]


def linear_convert(img):
    convert_scale = 255.0 / (np.max(img) - np.min(img))
    converted_img = convert_scale * img - (convert_scale * np.min(img))
    return converted_img


def resize_3d(ct_pet_image, size=256, reversed=False):
    if reversed:
        ct_pet_image = ct_pet_image[::-1].copy()
    list_ct_mri_slides = []
    for img in ct_pet_image:
        img = cv2.resize(img, (size, size))
        list_ct_mri_slides.append(img)
    return np.stack(list_ct_mri_slides)


def blend_with_mask(input, mask, alpha=0.9):
    return cv2.addWeighted(input, alpha, mask, 1 - alpha, 0)


def add_color_to_mask(mask):
    return np.stack([np.zeros_like(mask), np.zeros_like(mask), mask], axis=-1)
