
from collections import OrderedDict
import pandas as pd
import nibabel as nib
import SimpleITK as sitk
from radiomics.featureextractor import RadiomicsFeatureExtractor
import numpy as np
import mipkit


def cvt_array_to_ITKImage(np_image: np.ndarray) -> sitk.Image:
    """Convert numpy array to sitk.Image

    Args:
        np_image (np.ndarray): Input Numpy Array

    Returns:
        sitk.Image: MedicalImage file
    """
    return sitk.GetImageFromArray(np_image)


def load_medical_image_from_file(path_to_load: str, return_array_only=True):
    """Load medical file

    Args:
        path_to_load (str): Path to medical image file

    Returns:
        ndarray: Numpy array
    """
    # sitk_image = sitk.ReadImage(path_to_load)
    # return sitk.GetArrayFromImage(sitk_image)
    nib_obj = nib.load(path_to_load)
    if return_array_only:
        return nib_obj.get_data()
    else:
        return nib_obj


class RadiomicExtractor():
    def __init__(self,):
        self.texture_extractor = RadiomicsFeatureExtractor(verbose=False)
        self.texture_extractor.disableAllFeatures()
        _text_feat = {ckey: []
                      for ckey in self.texture_extractor.featureClassNames}
        self.texture_extractor.enableFeaturesByName(**_text_feat)
        self.drop_columns = ['diagnostics_Versions_PyRadiomics', 'diagnostics_Versions_Numpy',
                             'diagnostics_Versions_SimpleITK', 'diagnostics_Versions_PyWavelet',
                             'diagnostics_Versions_Python', 'diagnostics_Configuration_EnabledImageTypes',
                             'diagnostics_Configuration_Settings', 'diagnostics_Image-original_Hash',
                             'diagnostics_Image-original_Spacing', 'diagnostics_Image-original_Size',
                             'diagnostics_Mask-original_Hash', 'diagnostics_Image-original_Dimensionality',
                             'diagnostics_Mask-original_Spacing', 'diagnostics_Mask-original_VoxelNum', 'diagnostics_Image-original_Maximum',
                             'diagnostics_Image-original_Minimum', 'diagnostics_Mask-original_VolumeNum', 'diagnostics_Mask-original_CenterOfMassIndex',
                             'diagnostics_Mask-original_CenterOfMass', 'diagnostics_Mask-original_Size', 'diagnostics_Mask-original_BoundingBox']

    def postprocess(self, radiomic_features):
        for col in self.drop_columns:
            radiomic_features.pop(col)
        return OrderedDict([(key, float(val)) for key, val in radiomic_features.items()])

    def extract_radiomics(self, seg_mask_path, ct_path):
        # seg_mask = load_medical_image_from_file(seg_mask_path)
        # ct_data = load_medical_image_from_file(ct_path)

        seg_mask = mipkit.medical.load_medical_image_from_file(seg_mask_path)
        ct_data = mipkit.medical.load_medical_image_from_file(ct_path)

        if len(np.unique(seg_mask)) >= 2:
            radiomic_features = self.texture_extractor.execute(imageFilepath=cvt_array_to_ITKImage(ct_data),
                                                               maskFilepath=cvt_array_to_ITKImage((seg_mask).astype(np.uint8)))
            return self.postprocess(radiomic_features)
        else:
            return None
