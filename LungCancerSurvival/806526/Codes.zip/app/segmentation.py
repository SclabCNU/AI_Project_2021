# import mipkit
from monai.data import decollate_batch
import cv2
import torch
import mipkit

from monai.transforms import (
    Activations,
    AsDiscrete,
    Compose,
    LoadImaged,
    MapTransform,
    NormalizeIntensityd,
    Orientationd,
    Spacingd,
    EnsureChannelFirstd,
    EnsureTyped,
    EnsureType,
    LoadImaged
)
from monai.networks.nets import SegResNet
from monai.inferers import sliding_window_inference
import numpy as np


class LoadSEERImaged(LoadImaged):
    def __call__(self, data, reader=None):
        """
        Raises:
            KeyError: When not ``self.overwriting`` and key already exists in ``data``.

        """
        d = dict(data)
        for key, meta_key, meta_key_postfix in self.key_iterator(d, self.meta_keys, self.meta_key_postfix):
            if key == 'image':
                if self._loader.image_only:
                    data_ct = self._loader(d[key]['CT'], reader)
                    data_pet = self._loader(d[key]['PET'], reader)
                    data = np.stack([data_ct, data_pet], axis=0)
                else:
                    data_ct, shared_meta = self._loader(d[key]['CT'], reader)
                    data_pet, _ = self._loader(d[key]['PET'], reader)
                    shared_meta['spatial_shape'] = np.array(
                        [256, 256, 110], dtype=np.int16)
                    shared_meta['original_channel_dim'] = 0
                    data = (np.stack([data_ct, data_pet], axis=0), shared_meta)

            elif key == 'label':
                data = self._loader(d[key], reader)
            else:
                raise ValueError('Cannot handle key not in [image, label]')

            if self._loader.image_only:
                if not isinstance(data, np.ndarray):
                    raise ValueError(
                        "loader must return a numpy array (because image_only=True was used).")
                d[key] = data
            else:
                # raise ValueError('Only support ImageOnly')
                if not isinstance(data, (tuple, list)):
                    raise ValueError(
                        "loader must return a tuple or list (because image_only=False was used).")
                d[key] = data[0]
                if not isinstance(data[1], dict):
                    raise ValueError("metadata must be a dict.")
                meta_key = meta_key or f"{key}_{meta_key_postfix}"
                if meta_key in d and not self.overwriting:
                    raise KeyError(
                        f"Meta data with key {meta_key} already exists and overwriting=False.")
                d[meta_key] = data[1]
        return d


class FlipDiagonally(MapTransform):
    def do_flip_diagonally_on_3d(self, x):
        for i in range(len(x)):
            x[i] = self.do_flip_diagonally(x[i])
        return x

    def do_flip_diagonally(self, x):
        #! TODO: Optimize process time
        x = cv2.rotate(x, cv2.ROTATE_90_CLOCKWISE)
        x = cv2.flip(x, 0)
        return x

    def __call__(self, data):
        d = dict(data)
        for key in self.keys:
            d[key] = self.do_flip_diagonally_on_3d(d[key])
        return d


class UnsqueezeImage(MapTransform):
    def __call__(self, data):
        d = dict(data)
        for key in self.keys:
            d[key] = torch.unsqueeze(d[key], 0)
        return d


class InferenceSegResNet():
    def __init__(self, model_path,
                 roi_size=(224, 224, 72),
                 val_amp=True,
                 classification_threshold=0.5, device='cuda'):
        self.device = device
        self.model_path = model_path
        self.roi_size = roi_size
        self.classification_threshold = classification_threshold
        self.val_amp = val_amp
        self.model = self.load_model(model_path).to(device)
        self.input_transform = self.load_input_transform()
        self.output_transform = self.load_output_transform()
        self.file_loader = self.load_file_loader()

    def load_model(self, model_path):
        print('Load model: %s' % model_path)
        model = SegResNet(
            blocks_down=[1, 2, 2, 4],
            blocks_up=[1, 1, 1],
            init_filters=16,
            in_channels=2,
            out_channels=1,
            dropout_prob=0.2)

        ckpt_data = torch.load(model_path)
        model.load_state_dict(ckpt_data)
        model = model.eval()
        return model

    def load_file_loader(self):
        return LoadImaged(keys=['image'])

    def load_input_transform(self):
        return Compose(
            [
                # LoadSEERImaged(keys=["image"]),
                # EnsureChannelFirstd(keys="image"),
                Spacingd(
                    keys=["image"],
                    pixdim=(1.0, 1.0, 1.0),
                    mode=("bilinear"),
                ),
                Orientationd(keys=["image"], axcodes="RAS"),
                NormalizeIntensityd(keys="image",
                                    nonzero=True,
                                    channel_wise=True),
                EnsureTyped(keys=["image"]),
                UnsqueezeImage(keys=['image'])
            ]
        )

    def load_output_transform(self):
        return Compose([EnsureType(),
                        Activations(sigmoid=True),
                        AsDiscrete(threshold_values=True,
                                   logit_thresh=self.classification_threshold)]
                       )

    def _compute(self, model, input):
        return sliding_window_inference(
            inputs=input,
            roi_size=self.roi_size,
            sw_batch_size=1,
            predictor=model,
            overlap=0.5,
        )

    def post_preprocess(self, output):

        output = [self.output_transform(i)
                  for i in decollate_batch(output)][0]

        if self.device == 'cuda':
            output = output.cpu()
        output = output.detach().numpy().squeeze(0).transpose([2, 0, 1])
        output = np.array(
            list(map(lambda x: mipkit.medical.flip_diagonally(x), output)))
        output = output.astype(np.uint8)
        return output

    def load_pet_ct_image_from_path(self, ct_path, pet_path):

        ct_data = self.file_loader({'image': ct_path})
        pet_data = self.file_loader({'image': pet_path})
        ct_pet_tensor = ct_data.copy()

        # debug_input = np.stack([ct_data['image'], pet_data['image']], axis=0)
        # print(ct_data['image'].shape)
        # np.save('debug_input_std.npy', ct_data['image'])

        ct_pet_tensor['image'] = torch.from_numpy(np.stack(
            [ct_data['image'], pet_data['image']], axis=0))

        return ct_pet_tensor

    def get_radiomic_feature(self, path_to_ct_image, path_to_pet_image):
        seg_mask = self.inference(path_to_ct_image, path_to_pet_image)

    def inference(self, path_to_ct_image, path_to_pet_image):
        input = self.load_pet_ct_image_from_path(path_to_ct_image,
                                                 path_to_pet_image)

        input = self.input_transform(input)['image']

        if self.device == 'cuda':
            input = input.to(self.device)

        with torch.no_grad():
            if self.val_amp:
                with torch.cuda.amp.autocast():
                    output = self._compute(self.model, input)
            else:
                output = self._compute(self.model, input)

        output = self.post_preprocess(output)
        return output

    def segment(self, ct_image, pet_image):
        input = torch.from_numpy(np.stack([ct_image, pet_image], axis=0))
        input = self.input_transform({'image': input})['image']
        if self.device == 'cuda':
            input = input.to(self.device)

        with torch.no_grad():
            if self.val_amp:
                with torch.cuda.amp.autocast():
                    output = self._compute(self.model, input)
            else:
                output = self._compute(self.model, input)

        output = self.post_preprocess(output)
        # (w, h, d) -> (d, w, h)
        # import mipkit;mipkit.debug.set_trace();exit();
        output = output.transpose((2, 0, 1))
        return output

    def blend_with_mask(self, input, mask, alpha=0.6):
        return cv2.addWeighted(input, alpha, mask, 1 - alpha, 0)

    def load_ct_image(self, path_to_ct_image):
        ct_data = self.file_loader({'image': path_to_ct_image})['image']
        ct_data = ct_data.transpose([2, 0, 1]).astype(np.uint8)
        return ct_data


def to_monai_data(x):
    x = torch.from_numpy(x)
    return {'image': x}


if __name__ == '__main__':
    CKPT_PATH = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/code/app/thirdparty/Survival-Viewer/src/ckpt/best_metric_model.pth'
    model = InferenceSegResNet(CKPT_PATH)

    CT_PATH = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/PreCrop_LC_NSCLC_CT_n=2687/LC00009.nii'
    PET_PATH = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/PreCrop_LC_NSCLC_PET_n=2687/LC00009.nii'

    output_mask = model.inference(CT_PATH, PET_PATH)

    mipkit.medical.save_3d_file(output_mask, 'test.nii')
    print('Done')

    # ct_data = model.load_ct_image(CT_PATH)
    # blended_ct = model.blend_with_mask(ct_data, output_mask)
    # mipkit.medical.save_3d_file(blended_ct, 'test_blend.nii')
