# from enum import Enum
from survival.preprocessing import ordinal_encode_input, label_encode_input, draw_survival_curve
from survival.networks import InferenceDeepSurv
from collections import OrderedDict
import mipkit
from segmentation import InferenceSegResNet
import pandas as pd
import sys
import os
from PyQt5.QtCore import QThread, Qt
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtWidgets import QListWidgetItem, QSpacerItem, QSizePolicy
from PyQt5.QtWidgets import QFileDialog
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.uic import loadUi

import cv2
import dicom_file as ldf
import numpy as np
from preprocessing import crop_lung_image, extract_lung_slides, linear_convert, resize_3d
from preprocessing import normalize_CT_PET, load_DICOM_series, blend_with_mask, add_color_to_mask
from utils import get_logger
import threading
import time


from radiomic_extractor import RadiomicExtractor

os.makedirs('tmp', exist_ok=True)

logger = get_logger()

DEBUG = False


CKPT_PATH = 'ckpt/best_metric_model.pth'
SAVE_CT_PATH = 'tmp/ct_tmp.nii'
SAVE_PET_PATH = 'tmp/pet_tmp.nii'
SAVE_MASK_PATH = 'tmp/mask_tmp.nii'


class ImageType():
    # TODO: Prevent value changue in Enum-like Class
    CT = 1
    PET = 2


class SurvivalImageType():
    # TODO: Prevent value changue in Enum-like Class
    CUM_HAZARD_CURVE = 1
    SURVIVAL_CURVE = 2


class CMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        path = os.getcwd()
        # os.chdir(path + '/threeD')
        self.directory = os.getcwd()
        loadUi('main_window.ui', self)
        self.setWindowTitle('Survival Analysis Viewer')
        # self.image = None

        self.current_survival_type = SurvivalImageType.SURVIVAL_CURVE
        self.current_image_type = ImageType.CT
        self.current_voxel = None
        self.current_processedvoxel = None

        self.is_ct_loaded = False
        self.ct_voxel = None
        self.ct_processedvoxel = None

        self.is_pet_loaded = False
        self.pet_voxel = None
        self.pet_processedvoxel = None

        # Segmentation results
        self.segmentation_mask = None

        # Radiomic Features
        self.radiomic_features = None

        # Input image shape
        self.v1, self.v2, self.v3 = None, None, None

        self.surv_fn = None
        self.cum_hazard_fn = None

        # Status bar
        # self.statusbar.showMessage('This is the status bar')

        # self.label_x.rotate(90)
        # Load Input CT
        self.dicomCTButton.clicked.connect(self.dicom_ct_clicked)

        # Load Input PET
        self.dicomPETButton.clicked.connect(self.dicom_pet_clicked)

        # Load Clinical
        self.clinicalButton.clicked.connect(self.clinical_clicked)

        # Clear Button
        self.clearButton.clicked.connect(self.clear_all)

        # Prediction Buttion
        self.segmentationButton.clicked.connect(self.segmentation_predict)
        self.survivalButton.clicked.connect(self.survival_predict)

        self.survivalCurveButton.clicked.connect(self.change_survival_curve)

        # Slider Interaction
        self.axial_hSlider.valueChanged.connect(self.update_img)
        self.axial_vSlider.valueChanged.connect(self.update_img)
        self.sagittal_hSlider.valueChanged.connect(self.update_img)
        self.sagittal_vSlider.valueChanged.connect(self.update_img)
        self.coronal_hSlider.valueChanged.connect(self.update_img)
        self.coronal_vSlider.valueChanged.connect(self.update_img)
        self.colormap = None

        self.colormapBox.activated[str].connect(self.colormap_choice)
        self.colormapDict = {'GRAY': None,
                             'BONE': cv2.COLORMAP_BONE,
                             'HSV': cv2.COLORMAP_HSV,
                             'JET': cv2.COLORMAP_JET,
                             }

        self.w1, self.h1 = self.imgLabel_1.width(), self.imgLabel_1.height()
        self.w2, self.h2 = self.imgLabel_2.width(), self.imgLabel_2.height()
        self.w3, self.h3 = self.imgLabel_3.width(), self.imgLabel_3.height()

        self.imgLabel_1.type = 'axial'
        self.imgLabel_2.type = 'sagittal'
        self.imgLabel_3.type = 'coronal'

        self.axialGrid.setSpacing(0)
        self.saggitalGrid.setSpacing(0)
        self.coronalGrid.setSpacing(0)

        h = QSpacerItem(10, 10, QSizePolicy.Fixed, QSizePolicy.Fixed)
        v = QSpacerItem(10, 10, QSizePolicy.Fixed, QSizePolicy.Fixed)

        self.axial_vBox.setSpacing(0)
        self.axial_vBox.insertSpacerItem(0, v)
        self.axial_vBox.insertSpacerItem(2, v)
        self.axial_hBox.setSpacing(0)
        self.axial_hBox.insertSpacerItem(0, h)
        self.axial_hBox.insertSpacerItem(2, h)

        self.saggital_vBox.setSpacing(0)
        self.saggital_vBox.insertSpacerItem(0, v)
        self.saggital_vBox.insertSpacerItem(2, v)
        self.saggital_hBox.setSpacing(0)
        self.saggital_hBox.insertSpacerItem(0, h)
        self.saggital_hBox.insertSpacerItem(2, h)

        self.coronal_vBox.setSpacing(0)
        self.coronal_vBox.insertSpacerItem(0, v)
        self.coronal_vBox.insertSpacerItem(2, v)
        self.coronal_hBox.setSpacing(0)
        self.coronal_hBox.insertSpacerItem(0, h)
        self.coronal_hBox.insertSpacerItem(2, h)

        # Survival Curve Box
        self.survival_curve_vBox.setSpacing(0)
        self.survival_curve_vBox.insertSpacerItem(0, v)
        self.survival_curve_vBox.insertSpacerItem(2, v)
        self.survival_curve_hBox.setSpacing(0)
        self.survival_curve_hBox.insertSpacerItem(0, h)
        self.survival_curve_hBox.insertSpacerItem(2, h)

        self.colormap_hBox.insertStretch(2)
        self.colormap_hBox.insertSpacerItem(0, QSpacerItem(30, 0,
                                                           QSizePolicy.Fixed,
                                                           QSizePolicy.Fixed))

        # self.savesliceButton.clicked.connect(self.saveslice_clicked)
        self.dcm_info = None

        # Connect display area to update-center-mouse event
        self.imgLabel_1.mpsignal.connect(self.cross_center_mouse)
        self.imgLabel_2.mpsignal.connect(self.cross_center_mouse)
        self.imgLabel_3.mpsignal.connect(self.cross_center_mouse)
        self.cross_recalc = True

        # Change Image Button
        self.changeImageButton.clicked.connect(self.change_shown_image)

        # Clinical Information
        self.clinical_info = None
        self.is_clinical_loaded = False

        # Init here
        self.is_segment_model_loaded = False
        self.is_survival_model_loaded = False
        self.init_thread()

        # Status Checker Event Loop
        self.init_event_loop_thread()

    def segmentation_predict(self):
        # self.segmentation_mask = self.segment_model.segment(ct_image=self.ct_processedvoxel,
        #                                                     pet_image=self.pet_processedvoxel)
        segmentation_mask = self.segment_model.inference(SAVE_CT_PATH,
                                                         SAVE_PET_PATH)
        # Save mask for later process
        mipkit.medical.save_3d_file(segmentation_mask, SAVE_MASK_PATH)

        # Extract radiomic features after segmentation
        self.radiomic_features = self.radiomic_extractor.extract_radiomics(SAVE_MASK_PATH,
                                                                           SAVE_CT_PATH)
        # Resize and save segmeantaiton mask for visualization
        self.segmentation_mask = resize_3d(segmentation_mask,
                                           reversed=True,
                                           size=512)
        self.update_img()

    def survival_predict(self):

        import time
        t = time.time()
        if self.radiomic_features is None:
            self.segmentation_predict()
        t2 = time.time()
        # Combine clinical and radiomic features
        # Radiomic
        radiomic_df = pd.DataFrame(self.radiomic_features, index=[0])

        # Clinical
        clinical_df = pd.DataFrame(self.clinical_info, index=[0])

        # Clinical
        clinical_df = clinical_df.rename(
            columns={'Clinical.T.Stage': 'Clinical.T.stage'})

        clinical_df = clinical_df.drop(columns=['PatientID',
                                                'Mcode',
                                                'Mcode.description',
                                                ])

        df = pd.concat([clinical_df, radiomic_df], axis=1)

        # Radiomic
        df.iloc[:, 9:] = self.survival_model.scaler.transform(df.iloc[:, 9:])

        # One-hot encoding
        df['Age'] /= 100  # Normalize age
        # df = label_encode_input(df, column_name='Gender')
        df['Gender'] = 1.0 if df['Gender'].iloc[0] == 'male' else 0.0

        df.loc[0, 'Histology_NOS'] = 0.0
        df.loc[0, 'Histology_adenocarcinoma'] = 0.0
        df.loc[0, 'Histology_large cell'] = 0.0
        df.loc[0, 'Histology_squamous cell carcinoma'] = 0.0
        df.loc[0, 'Overall.stage_1A'] = 0.0
        df.loc[0, 'Overall.stage_1B'] = 0.0
        df.loc[0, 'Overall.stage_2A'] = 0.0
        df.loc[0, 'Overall.stage_2B'] = 0.0
        df.loc[0, 'Overall.stage_3A'] = 0.0
        df.loc[0, 'Overall.stage_3B'] = 0.0
        df.loc[0, 'Overall.stage_3b'] = 0.0
        df.loc[0, 'Clinical.T.stage_1'] = 0.0
        df.loc[0, 'Clinical.T.stage_2'] = 0.0
        df.loc[0, 'Clinical.T.stage_3'] = 0.0
        df.loc[0, 'Clinical.T.stage_4'] = 0.0
        df.loc[0, 'Clinical.M.stage_0'] = 0.0
        df.loc[0, 'Clinical.M.stage_1'] = 0.0
        df.loc[0, 'Clinical.N.stage_0'] = 0.0
        df.loc[0, 'Clinical.N.stage_1'] = 0.0
        df.loc[0, 'Clinical.N.stage_2'] = 0.0
        df.loc[0, 'Clinical.N.stage_3'] = 0.0

        for col in ['Histology',  'Overall.stage',
                    'Clinical.T.stage', 'Clinical.M.stage',
                    'Clinical.N.stage']:
            if col == 'Histology' or col == 'Overall.stage':
                df.loc[0, col + '_' + str(df[col].iloc[0])] = 1.0
            else:
                df.loc[0, col + '_' + str(int(df[col].iloc[0]))] = 1.0

        df = df.drop(columns=['Histology',  'Overall.stage',
                              'Clinical.T.stage', 'Clinical.M.stage',
                              'Clinical.N.stage'])
        # df = pd.get_dummies(df, columns=['Histology',  'Overall.stage',
        #                                  'Clinical.T.stage', 'Clinical.M.stage',
        #                                  'Clinical.N.stage'])

        df['Smoking.amount'] = self.survival_model.minmax_scaler.transform(
            df['Smoking.amount'].values.reshape((-1, 1))).reshape(-1)

        # radiomic_features = self.survival_model.scaler.transform(radiomic_df)

        # radiomic_features = radiomic_features.flatten().astype(np.float32)
        # clinical_features = clinical_df.values.flatten().astype(np.float32)

        # import mipkit
        # mipkit.debug.set_trace()
        # exit()

        # X = np.concatenate([clinical_features, radiomic_features])
        X = df.values.astype(np.float32)
        # X = np.expand_dims(X, 0)

        # mipkit.save_object(X, 'survival_input.pkl')
        # logger.debug('Save survival_input at `survival_input.pkl`')

        risk_pred = self.survival_model.forward(X)

        self.surv_fn = self.survival_model.get_survival_function(risk_pred)
        self.cum_hazard_fn = self.survival_model.get_cumulative_hazard_function(
            risk_pred)

        t3 = time.time()

        logger.debug(f"Inference Time: Segmentation: {t2 - t}")
        logger.debug(f"Inference Time: Survival: {t3 - t2}")
        logger.debug(f"Inference Time (2 Steps): {t3 - t}")

        # Draw survival function
        # draw_survival_curve(surv_fn)
        if self.current_survival_type == SurvivalImageType.SURVIVAL_CURVE:
            self.update_survival_curve()
        else:
            self.update_cumulative_hazard_curve()

    def change_survival_curve(self):
        if self.surv_fn is not None and self.cum_hazard_fn is not None:
            if self.current_survival_type == SurvivalImageType.CUM_HAZARD_CURVE:
                self.current_survival_type = SurvivalImageType.SURVIVAL_CURVE
                self.survivalCurveButton.setText("Show Survival Curve")
                self.update_survival_curve()
            else:
                self.current_survival_type = SurvivalImageType.CUM_HAZARD_CURVE
                self.survivalCurveButton.setText(
                    "Show Cummulative Hazard Curve")
                self.update_cumulative_hazard_curve()

    def update_survival_curve(self):
        self.survivalImage.update_survival_curve(self.surv_fn)

    def update_cumulative_hazard_curve(self):
        self.survivalImage.update_cumulative_hazard_curve(self.cum_hazard_fn)

    def init_model(self):
        self.segment_model = InferenceSegResNet(CKPT_PATH)
        self.is_segment_model_loaded = True
        logger.debug("Init Segmentation Model")

        self.survival_model = InferenceDeepSurv()
        self.is_survival_model_loaded = True
        logger.debug("Init InferenceDeepSurv")

        self.radiomic_extractor = RadiomicExtractor()
        logger.debug("Init Radiomic Extractor")

    def init_thread(self):
        """Initialize the model here"""
        init_model_th = threading.Thread(target=self.init_model)
        init_model_th.setDaemon(True)
        init_model_th.start()

    def init_event_loop_thread(self):
        th = threading.Thread(target=self.event_loop)
        th.setDaemon(True)
        th.start()
        logger.debug("Event loop started")

    def event_loop(self):
        while True:
            if self.is_ct_loaded and self.is_pet_loaded and self.is_segment_model_loaded:
                self.segmentationButton.setEnabled(True)
            else:
                self.segmentationButton.setEnabled(False)

            if self.is_ct_loaded and self.is_pet_loaded and self.is_segment_model_loaded and self.is_clinical_loaded and self.is_survival_model_loaded:
                self.survivalButton.setEnabled(True)
            else:
                self.survivalButton.setEnabled(False)

            time.sleep(0.1)

    def update_clinical_list(self):
        """Update Clinical Information on Qlist"""
        assert self.clinical_info is not None
        for key, val in self.clinical_info.items():
            self.clinicalList.addItem(QListWidgetItem(
                '%-30s\t:  %s' % (key, val)))

    def clear_all(self):
        logger.debug("Clicked Clear All button")
        self.current_image_type = ImageType.CT
        self.current_voxel = None
        self.current_processedvoxel = None

        self.is_ct_loaded = False
        self.ct_voxel = None
        self.ct_processedvoxel = None

        self.is_pet_loaded = False
        self.pet_voxel = None
        self.pet_processedvoxel = None

        self.v1, self.v2, self.v3 = None, None, None

        self.update_img()
        self.imgLabel_1.reset()
        self.imgLabel_2.reset()
        self.imgLabel_3.reset()

        self.dcmList.clear()
        self.clinicalList.clear()
        self.is_clinical_loaded = False
        self.clinical_info = None

        self.survivalImage.clear()

        # Segmentation results
        self.segmentation_mask = None

        # Radiomic Features
        self.radiomic_features = None

        self.is_radiomic_loaded = False
        self.radiomic_features = None
        self.clinical_features = None
        self.surv_fn = None
        self.cum_hazard_fn = None

    def change_shown_image(self):
        """Change CT to PET or PET to CT"""
        if self.is_pet_loaded and self.is_ct_loaded:
            if self.current_image_type == ImageType.PET:
                self.current_processedvoxel = self.ct_processedvoxel.copy()
                self.current_image_type = ImageType.CT
                self.changeImageButton.setText('Show CT Slides')

            elif self.current_image_type == ImageType.CT:
                self.current_processedvoxel = self.pet_processedvoxel.copy()
                self.current_image_type = ImageType.PET
                self.changeImageButton.setText('Show PET Slides')
            else:
                raise
        self.update_img()

    def set_directory(self):
        os.chdir(self.directory)

    def cross_center_mouse(self, _type):
        self.cross_recalc = False
        if _type == 'axial':
            self.axial_hSlider.setValue(int(
                self.imgLabel_1.crosscenter[0] * self.axial_hSlider.maximum() / self.imgLabel_1.width()))
            self.axial_vSlider.setValue(int(
                self.imgLabel_1.crosscenter[1] * self.axial_vSlider.maximum() / self.imgLabel_1.height()))
        elif _type == 'sagittal':
            self.sagittal_hSlider.setValue(int(self.imgLabel_2.crosscenter[0] *
                                               self.sagittal_hSlider.maximum() / self.imgLabel_2.width()))
            self.sagittal_vSlider.setValue(int(self.imgLabel_2.crosscenter[1] *
                                               self.sagittal_vSlider.maximum() / self.imgLabel_2.height()))
        elif _type == 'coronal':
            self.coronal_hSlider.setValue(int(self.imgLabel_3.crosscenter[0] *
                                              self.coronal_hSlider.maximum() / self.imgLabel_3.width()))
            self.coronal_vSlider.setValue(int(self.imgLabel_3.crosscenter[1] *
                                              self.coronal_vSlider.maximum() / self.imgLabel_3.height()))
        else:
            raise

        self.imgLabel_1.crosscenter = [
            self.axial_hSlider.value() * self.imgLabel_1.width() /
            self.axial_hSlider.maximum(),
            self.axial_vSlider.value() * self.imgLabel_1.height() / self.axial_vSlider.maximum()]

        self.imgLabel_2.crosscenter = [
            self.sagittal_hSlider.value() * self.imgLabel_2.width() /
            self.sagittal_hSlider.maximum(),
            self.sagittal_vSlider.value() * self.imgLabel_2.height() / self.sagittal_vSlider.maximum()]

        self.imgLabel_3.crosscenter = [
            self.coronal_hSlider.value() * self.imgLabel_3.width() /
            self.coronal_hSlider.maximum(),
            self.coronal_vSlider.value() * self.imgLabel_3.height() / self.coronal_vSlider.maximum()]

        self.update_img()
        self.cross_recalc = True

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.w = self.imgLabel_1.width()
        self.h = self.imgLabel_1.height()
        if self.current_processedvoxel is not None:
            self.update_img()

    def colormap_choice(self, text):
        self.colormap = self.colormapDict[text]
        self.update_img()

    # Dicom CT Input
    def dicom_ct_clicked(self):

        if DEBUG:
            dname = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/demo_samples/CT_LC00009'
        else:
            dname = QFileDialog.getExistingDirectory(self,
                                                     caption='Choose dicom directory')

        if os.path.exists(dname):
            logger.debug(f'Load CT file from {dname}')
            self.current_image_type = ImageType.CT
            self.load_dicomfile(dname)
            self.is_ct_loaded = True
            logger.debug('Load CT Done.')

    # Dicom PET Input
    def dicom_pet_clicked(self):
        if DEBUG:
            dname = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/demo_samples/LC00009'
        else:
            dname = QFileDialog.getExistingDirectory(self,
                                                     caption='Choose dicom directory')

        if os.path.exists(dname):
            logger.debug(f'Load PET file from {dname}')
            self.current_image_type = ImageType.PET
            self.load_dicomfile(dname)
            self.is_pet_loaded = True
            logger.debug('Load PET Done.')

    # Clinical Input
    def clinical_clicked(self):
        if DEBUG:
            filepath = (
                '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/demo_samples/LC_NSCLC_CLINICAL_sample.xlsx', '')
        else:
            # self, 'open file', '~/Desktop', "Image Files (*.NPY *.npy)")
            filepath = QFileDialog.getOpenFileName(self,
                                                   'Choose clinical file',
                                                   '~/Desktop',
                                                   filter="Excel Files (*.XLSX *.xlsx)")
        if os.path.isfile(filepath[0]):
            # TODO: Load clinical file
            self.clinical_info = self.load_excel_file(filepath[0])
            self.update_clinical_list()
            self.is_clinical_loaded = True

    def load_excel_file(self, file_path):
        df = pd.read_excel(file_path)
        return OrderedDict([(col_name, df[col_name].iloc[0]) for col_name in df.columns if 'Unnamed' not in col_name])

    def load_dicomfile(self, dname) -> bool:
        """Load dicom file from specified path

        Args:
            dname (str): path to dicom filename

        Returns:
            bool: successful
        """
        # try:
        self.dcmList.clear()
        voxel = load_DICOM_series(dname)
        # voxel = ldf.load_scan(dname)
        self.dcm_info = ldf.load_dcm_info(dname, False)
        # voxel = ldf.get_pixels_hu(voxel)

        # TODO: Preprocess voxel here
        voxel = crop_lung_image(voxel)
        voxel_ = extract_lung_slides(voxel)
        voxel_ = normalize_CT_PET(voxel_)
        voxel_ = resize_3d(voxel_, size=512, reversed=True)

        # if self.current_image_type == ImageType.PET:
        #     alpha = 1.5 # Contrast control (1.0-3.0)
        #     beta = 0 # Brightness control (0-100)
        #     voxel_ = cv2.convertScaleAbs(voxel_, alpha=alpha, beta=beta)

        processedvoxel = voxel_.copy()

        if self.current_image_type == ImageType.CT:

            # TODO: Not really effective
            voxel = normalize_CT_PET(voxel)
            voxel = extract_lung_slides(voxel)
            voxel = resize_3d(voxel, size=256, reversed=False)
            mipkit.medical.save_3d_file(voxel, SAVE_CT_PATH)
            
            self.ct_processedvoxel = processedvoxel.copy()
            self.current_processedvoxel = processedvoxel.copy()

        elif self.current_image_type == ImageType.PET:

            # TODO: Not really effective
            voxel = normalize_CT_PET(voxel)
            voxel = extract_lung_slides(voxel)
            voxel = resize_3d(voxel, size=256, reversed=False)
            mipkit.medical.save_3d_file(voxel, SAVE_PET_PATH)

            self.pet_processedvoxel = processedvoxel.copy()
            self.current_processedvoxel = processedvoxel.copy()
        else:
            raise

        # Update after load
        # Update slider only one time
        if not self.is_ct_loaded or not self.is_pet_loaded:
            self.update_shape()

        self.imgLabel_1.setMouseTracking(True)
        self.imgLabel_2.setMouseTracking(True)
        self.imgLabel_3.setMouseTracking(True)

        self.update_img()
        self.set_directory()

        self.update_dicom_list()

    def update_shape(self) -> None:
        """Update slicer resolution"""
        self.v1, self.v2, self.v3 = self.current_processedvoxel.shape

        logger.debug('Max_sagittal_vSlider: {}'.format(self.v1))

        self.sagittal_vSlider.setMaximum(self.v1 - 1)
        self.coronal_vSlider.setMaximum(self.v1 - 1)
        self.sagittal_hSlider.setMaximum(self.v2 - 1)

        self.axial_vSlider.setMaximum(self.v2 - 1)
        self.coronal_hSlider.setMaximum(self.v3 - 1)
        self.axial_hSlider.setMaximum(self.v3 - 1)

        self.sagittal_vSlider.setValue(self.sagittal_vSlider.maximum() // 2)
        self.coronal_vSlider.setValue(self.coronal_vSlider.maximum() // 2)
        self.sagittal_hSlider.setValue(self.sagittal_hSlider.maximum() // 2)

        self.axial_vSlider.setValue(self.axial_vSlider.maximum() // 2)
        self.coronal_hSlider.setValue(self.coronal_hSlider.maximum() // 2)
        self.axial_hSlider.setValue(self.axial_hSlider.maximum() // 2)

    def update_dicom_list(self) -> None:
        """Update DCM Information on Qlist"""
        for item in self.dcm_info:
            self.dcmList.addItem(QListWidgetItem(
                '%-20s\t:  %s' % (item[0], item[1])))

    def update_img(self):
        if self.current_processedvoxel is not None:
            a_loc = self.sagittal_vSlider.value()
            c_loc = self.axial_vSlider.value()
            s_loc = self.axial_hSlider.value()

            self.imgLabel_1.slice_loc = [s_loc, c_loc, a_loc]
            self.imgLabel_2.slice_loc = [s_loc, c_loc, a_loc]
            self.imgLabel_3.slice_loc = [s_loc, c_loc, a_loc]

            if self.cross_recalc:
                self.imgLabel_1.crosscenter = [
                    self.w1*s_loc//self.v3, self.h1*c_loc//self.v2]
                self.imgLabel_2.crosscenter = [
                    self.w2*c_loc//self.v2, self.h2*a_loc//self.v1]
                self.imgLabel_3.crosscenter = [
                    self.w3*s_loc//self.v3, self.h3*a_loc//self.v1]

            axial = (self.current_processedvoxel[a_loc, :, :]).astype(
                np.uint8).copy()
            sagittal = (self.current_processedvoxel[:, :, s_loc]).astype(
                np.uint8).copy()
            coronal = (self.current_processedvoxel[:, c_loc, :]).astype(
                np.uint8).copy()

            if self.segmentation_mask is not None:
                axial_mask = (self.segmentation_mask[a_loc, :, :]).astype(
                    np.uint8).copy()*255
                sagittal_mask = (self.segmentation_mask[:, :, s_loc]).astype(
                    np.uint8).copy()*255
                coronal_mask = (self.segmentation_mask[:, c_loc, :]).astype(
                    np.uint8).copy()*255

                # Convert GRAY to RGB
                axial = np.expand_dims(axial, axis=-1)
                sagittal = np.expand_dims(sagittal, axis=-1)
                coronal = np.expand_dims(coronal, axis=-1)

                axial = cv2.cvtColor(axial, cv2.COLOR_GRAY2RGB)
                sagittal = cv2.cvtColor(sagittal, cv2.COLOR_GRAY2RGB)
                coronal = cv2.cvtColor(coronal, cv2.COLOR_GRAY2RGB)

                axial_mask = add_color_to_mask(axial_mask)
                sagittal_mask = add_color_to_mask(sagittal_mask)
                coronal_mask = add_color_to_mask(coronal_mask)

                axial = blend_with_mask(axial, axial_mask)
                sagittal = blend_with_mask(sagittal, sagittal_mask)
                coronal = blend_with_mask(coronal, coronal_mask)

            if self.colormap is None:
                self.imgLabel_1.processedImage = axial
                self.imgLabel_2.processedImage = sagittal
                self.imgLabel_3.processedImage = coronal
            else:
                # Apply color map
                self.imgLabel_1.processedImage = cv2.applyColorMap(
                    axial, self.colormap)
                self.imgLabel_2.processedImage = cv2.applyColorMap(
                    sagittal, self.colormap)
                self.imgLabel_3.processedImage = cv2.applyColorMap(
                    coronal, self.colormap)

            self.imgLabel_1.display_image(1)
            self.imgLabel_2.display_image(1)
            self.imgLabel_3.display_image(1)

            # Update Change Image State
            if self.current_image_type == ImageType.CT:
                self.changeImageButton.setText('Show PET Slides')
            else:
                self.changeImageButton.setText('Show CT Slides')


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = CMainWindow()
    window.setWindowTitle(
        'Survival Analysis Project - Vo Minh Cong - Chonnam National University')
    window.show()
    sys.exit(app.exec_())
