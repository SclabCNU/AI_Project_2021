import cv2
import mipkit
import sys
from monai.data import CacheDataset
from monai.transforms import LoadImaged, Randomizable
import torch
from monai.utils import set_determinism
from monai.transforms import (
    Activations,
    Activationsd,
    AsDiscrete,
    AsDiscreted,
    Compose,
    MapTransform,
    NormalizeIntensityd,
    Orientationd,
    Spacingd,
    EnsureChannelFirstd,
    EnsureTyped,
    EnsureType,
)
from monai.networks.nets import SegResNet
from monai.inferers import sliding_window_inference
from monai.data import DataLoader, decollate_batch
from monai.config import print_config
import numpy as np
import matplotlib.pyplot as plt
import os
from tqdm import tqdm


# https://github.com/Project-MONAI/MONAI/issues/701
import resource
rlimit = resource.getrlimit(resource.RLIMIT_NOFILE)
resource.setrlimit(resource.RLIMIT_NOFILE, (4096, rlimit[1]))

# !pip install pytorch-ignite
print_config()
set_determinism(seed=1)


class ConvertToMultiChannelBasedOnBratsClassesd(MapTransform):
    """
    Convert labels to multi channels based on brats classes:
    label 1 is the peritumoral edema
    label 2 is the GD-enhancing tumor
    label 3 is the necrotic and non-enhancing tumor core
    The possible classes are TC (Tumor core), WT (Whole tumor)
    and ET (Enhancing tumor).

    """

    def __call__(self, data):
        d = dict(data)
        for key in self.keys:
            result = []
            # merge label 2 and label 3 to construct TC
            result.append(np.logical_or(d[key] == 2, d[key] == 3))
            # merge labels 1, 2 and 3 to construct WT
            result.append(
                np.logical_or(
                    np.logical_or(d[key] == 2, d[key] == 3), d[key] == 1
                )
            )
            # label 2 is ET
            result.append(d[key] == 2)
            d[key] = np.stack(result, axis=0).astype(np.float32)
        return d


class UnsqueezeLabel(MapTransform):

    def __call__(self, data):
        d = dict(data)
        for key in self.keys:
            d[key] = np.expand_dims(d[key], axis=0).astype(np.float32)
        return d


class LoadSEERImaged(LoadImaged):
    def __call__(self, data, reader=None):
        """
        Raises:
            KeyError: When not ``self.overwriting`` and key already exists in ``data``.

        """
        d = dict(data)
        for key, meta_key, meta_key_postfix in self.key_iterator(d, self.meta_keys, self.meta_key_postfix):
            if key == 'image':
                if self._loader.image_only:
                    data_ct = self._loader(d[key]['CT'], reader)
                    data_pet = self._loader(d[key]['PET'], reader)
                    data = np.stack([data_ct, data_pet], axis=0)
                else:
                    data_ct, shared_meta = self._loader(d[key]['CT'], reader)
                    data_pet, _ = self._loader(d[key]['PET'], reader)
                    shared_meta['spatial_shape'] = np.array(
                        [256, 256, 110], dtype=np.int16)
                    shared_meta['original_channel_dim'] = 0
                    data = (np.stack([data_ct, data_pet], axis=0), shared_meta)

            elif key == 'label':
                data = self._loader(d[key], reader)
            else:
                raise ValueError('Cannot handle key not in [image, label]')

            if self._loader.image_only:
                if not isinstance(data, np.ndarray):
                    raise ValueError(
                        "loader must return a numpy array (because image_only=True was used).")
                d[key] = data
            else:
                # raise ValueError('Only support ImageOnly')
                if not isinstance(data, (tuple, list)):
                    raise ValueError(
                        "loader must return a tuple or list (because image_only=False was used).")
                d[key] = data[0]
                if not isinstance(data[1], dict):
                    raise ValueError("metadata must be a dict.")
                meta_key = meta_key or f"{key}_{meta_key_postfix}"
                if meta_key in d and not self.overwriting:
                    raise KeyError(
                        f"Meta data with key {meta_key} already exists and overwriting=False.")
                d[meta_key] = data[1]
        return d


# Setup transforms for training and validation
test_transform = Compose(
    [
        LoadSEERImaged(keys=["image"]),
        EnsureChannelFirstd(keys="image"),
        Spacingd(
            keys=["image"],
            pixdim=(1.0, 1.0, 1.0),
            mode=("bilinear"),
        ),
        Orientationd(keys=["image"], axcodes="RAS"),
        NormalizeIntensityd(keys="image", nonzero=True, channel_wise=True),
        EnsureTyped(keys=["image"]),
    ]
)


class LungCNUDataset(Randomizable, CacheDataset):
    """
    Args:
        root_dir: user's local directory for caching and loading the MSD datasets.
        transform: transforms to execute operations on input data.
            for further usage, use `AddChanneld` or `AsChannelFirstd` to convert the shape to [C, H, W, D].
        seed: random seed to randomly shuffle the datalist before splitting into training and validation, default is 0.
            note to set same seed for `training` and `validation` sections.
        cache_num: number of items to be cached. Default is `sys.maxsize`.
            will take the minimum of (cache_num, data_length x cache_rate, data_length).
        cache_rate: percentage of cached data in total, default is 1.0 (cache all).
            will take the minimum of (cache_num, data_length x cache_rate, data_length).
        num_workers: the number of worker threads to use.
            if 0 a single thread will be used. Default is 0.

    Example::

        transform = Compose(
            [
                LoadImaged(keys=["image", "label"]),
                AddChanneld(keys=["image", "label"]),
                ScaleIntensityd(keys="image"),
                ToTensord(keys=["image", "label"]),
            ]
        )

        val_data = LungCNUDataset(
            root_dir="./", transform=transform, seed=12345
        )

        print(val_data[0]["image"], val_data[0]["label"])

    """

    def __init__(
            self,
            img_list,
            root_dir: str,
            transform=(),
            split: str = 'train',
            seed: int = 0,
            cache_num: int = sys.maxsize,
            cache_rate: float = 1.0,
            num_workers: int = 0):

        assert split in ['train', 'test']
        if not os.path.isdir(root_dir):
            raise ValueError("Root directory root_dir must be a directory.")

        with open(img_list, 'r') as f:
            self.img_list = [line.strip() for line in f]

        print("Processing {} datas".format(len(self.img_list)))
        self.split = split
        self.set_random_state(seed=seed)
        self.root_dir = root_dir
        self.indices: np.ndarray = np.array([])
        data = self._generate_data_list()
        if transform == ():
            transform = LoadImaged(["image", "label"])
        CacheDataset.__init__(
            self, data, transform, cache_num=cache_num, cache_rate=cache_rate, num_workers=num_workers
        )

    def randomize(self, data) -> None:
        self.R.shuffle(data)

    def _generate_data_list(self):
        data_list = []
        for idx in range(len(self.img_list)):
            ith_info = self.img_list[idx].split(" ")  # 0: CT, 1: PET, 2: Seg
            patient_id = ith_info[0].split('/')[-1].split('.')[0]
            # ['PreCrop_LC_NSCLC_CT_n=2687/LC00009']
            ct_img_name = os.path.join(self.root_dir, ith_info[0])
            pet_img_name = os.path.join(self.root_dir, ith_info[1])

            if self.split == 'train':
                label_name = os.path.join(self.root_dir, ith_info[2])
                data_list.append({
                    'patient_id': patient_id,
                    'image': {'CT': ct_img_name,
                              'PET': pet_img_name},
                    'label': label_name
                })
            else:
                data_list.append({
                    'patient_id': patient_id,
                    'image': {'CT': ct_img_name,
                              'PET': pet_img_name}})
        return data_list


# here we don't cache any data in case out of memory issue
root_dir = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202'
test_img_list = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/test.txt'

test_ds = LungCNUDataset(
    img_list=test_img_list,
    root_dir=root_dir,
    split='test',
    transform=test_transform,
    cache_rate=0.0,
    num_workers=1,
)

test_loader = DataLoader(test_ds, batch_size=1, shuffle=False, num_workers=4)

val_interval = 1
VAL_AMP = True

# Standard PyTorch program style: create SegResNet, DiceLoss and Adam optimizer
device = torch.device("cuda:0")
model = SegResNet(
    blocks_down=[1, 2, 2, 4],
    blocks_up=[1, 1, 1],
    init_filters=16,
    in_channels=2,
    out_channels=1,
    dropout_prob=0.2).to(device)

CKPT_PATH = 'ckpt/11-01-2021_11-15-03/best_metric_model.pth'
ckpt_data = torch.load(CKPT_PATH)
model.load_state_dict(ckpt_data)


def inference(input, model):
    # Inference method
    def _compute(input):
        return sliding_window_inference(
            inputs=input,
            roi_size=(224, 224, 72),
            sw_batch_size=1,
            predictor=model,
            overlap=0.5,
        )

    if VAL_AMP:
        with torch.cuda.amp.autocast():
            return _compute(input)
    else:
        return _compute(input)


THRESHOLD = 0.5
post_trans = Compose(
    [EnsureType(), Activations(sigmoid=True), AsDiscrete(
        threshold_values=True, logit_thresh=THRESHOLD)]
)

# MASK_PATH_TO_SAVE = '/mnt/mssd1T/LungCancer/LC_NSCLC_Cleaned_n=2687_20210202/PreCrop_LC_NSCLC_Mask_n=2687'

MASK_PATH_TO_SAVE = './'

def flip_diagonally(x):
    #! TODO: Optimize process time
    x = cv2.rotate(x, cv2.ROTATE_90_CLOCKWISE)
    x = cv2.flip(x, 0)
    return x


model.eval()
with torch.no_grad():
    for test_data in tqdm(test_loader):
        patient_id = test_data["patient_id"][0]
        test_inputs = test_data["image"].to(device)

        # import numpy as np
        # test_inputs = test_inputs.cpu()
        # np.save('LC00009-test-nii.npy', test_inputs)
        
        test_outputs = inference(test_inputs, model)
        test_outputs = [post_trans(i)
                        for i in decollate_batch(test_outputs)]

        path_to_save = os.path.join(MASK_PATH_TO_SAVE, f'{patient_id}.nii')
        test_outputs = test_outputs[0].detach().cpu().numpy().squeeze(0).transpose([2, 0, 1])

        test_outputs = np.array(
            list(map(lambda x: mipkit.medical.flip_diagonally(x), test_outputs)))
        test_outputs = test_outputs.astype(np.uint8)
        mipkit.medical.save_3d_file(test_outputs, path_to_save)
