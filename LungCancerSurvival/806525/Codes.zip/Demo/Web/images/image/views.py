from django.shortcuts import render, redirect
from django.conf import settings
from django.core.files.storage import FileSystemStorage

from image.models import Document
from image.forms import DocumentForm


def home(request):
    documents = Document.objects.all()
    return render(request, 'home.html', {'documents': documents})


def uploader(request, name):
    myfile = request.FILES[name]
    fs = FileSystemStorage()
    filename = fs.save(myfile.name, myfile)
    uploaded_file_url = fs.url(filename)
    return uploaded_file_url

def save_db(request, name):
    file = request.FILES.get(name)
    try:
        document = Document()
        document.document=file
        document.is_ct = True if name == 'myfile1' else False
        document.is_pet = not document.is_ct
        document.save()
    except Exception as e:
        print (e)

def simple_upload(request):
    lasted_ct_file = Document.objects.filter(is_ct=True).last()
    lasted_pet_file = Document.objects.filter(is_pet=True).last()
    uploaded_file_url = None
    if request.method == 'POST':
        if request.FILES.get('myfile1'):
            save_db(request,'myfile1')
            uploaded_file_url = uploader(request, 'myfile1')
        if request.FILES.get('myfile2'):
            save_db(request,'myfile2')
            uploaded_file_url = uploader(request, 'myfile2')
        lasted_ct_file = Document.objects.filter(is_ct=True).last()
        lasted_pet_file = Document.objects.filter(is_pet=True).last()

    return render(request, 'simple_upload.html', {
            'uploaded_file_url': uploaded_file_url,'lasted_pet_file':lasted_pet_file,'lasted_ct_file':lasted_ct_file
        })

