from django.apps import AppConfig


class ImageConfig(AppConfig):
    name = 'image'
